# groqchat-lib

Библиотека для работы с Groq API: сессии, RAG, полная история, аудит всех действий.

## Установка
```bash
pip install -e .

from groqchat_lib import GroqChat

chat = GroqChat(api_key="...")
chat.new_session("demo")
print(chat.get_answer("Привет!"))
print(chat.rag_query_from_file("Что в PDF?", "doc.pdf", strict_context=True))

---

### 4. `groqchat_lib/__init__.py`
```python
from .core import GroqChat
from .exceptions import GroqChatError, SessionError, RAGError

__version__ = "0.2.0"
__all__ = ["GroqChat", "GroqChatError", "SessionError", "RAGError"]